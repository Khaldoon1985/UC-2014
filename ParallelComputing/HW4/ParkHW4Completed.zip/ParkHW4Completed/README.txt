The code worked in Udacity, but I couldn't seem to make it work in the Tesla machine.

I am attaching the results screen shot from the Udacity website.