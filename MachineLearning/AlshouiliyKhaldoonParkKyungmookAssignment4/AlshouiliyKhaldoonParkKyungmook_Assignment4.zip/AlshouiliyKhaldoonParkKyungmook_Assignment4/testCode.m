Data = -100 + 200.*rand(100,2);
[rd, cd] = size(Data);

for i = 1:rd
    if(Data(i,1) + 2*Data(i,2) - 2 > 0)
        Targetl(i) = 1;
    else
        Targetl(i) = -1;
    end
end

Target=Targetl';
[rt, ct]=size(Target);
eta = 0.00001;
error = 0.005;
epochs = 100;
DeltaRuleBatchTrain(Data,Target,eta,error,epochs);