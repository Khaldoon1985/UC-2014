%Machine Learning Assignment 4

% B = DeltaRuleBatchTrain(X,Y,LearningRate,MinimumWeightChange,MaximumPasses,B0)
%
% B                    = Discovered coefficients
%
% X                    = Predictors (exemplars in rows, variables in columns)
% Y                    = Target variable (0/1 values)
% LearningRate         = Learning rate                             (try 0.05)
% MinimumWeightChange  = Minimum change in weight norm to continue (try 0.01)
% MaximumPasses        = Maximum number of training passes         (try 50)
% B0                   = Initial guess for coefficients (optional, NaN for none)

% % Generate some random data
% X = randn(2500,4);
% Y = double( (X(:,1) < 0.1) & (X(:,2) > 0.2) );
%
% % Train single neuron model using delta rule
% B = DeltaRule(X,Y,0.05,0.01,50);
%
% % Recall using discovered model
% Z = Logistic(B(1) + X * B(2:end));
%
% % Measure resubstitution accuracy
% mean(Y == (Z > 0.5))

% Generate random pairs (x1, x2)
% g = x1 + 2*x2 - 2
% if x1 + 2*x2 - 2 > 0, assign results to positive class, i.e. 1
% if x1 + 2*x2 - 2 < 0 or x1 + 2*x2 - 2 = 0,
% assign results to negative class, i.e. 2
hold on

n = 100;
N = 50;

% Changed Learning Rate from 0.05, 1, 5, 10
% The prediction gets worse and worse
LearningRate = 10;
MinimumWeightChange = 0.01;
MaximumPasses = N;
% Initial Guess
% B0

%X = randn(n,2);
%Y = double( X(:,1) + 2.*X(:,2) - 2 > 0 );
E = 1:N;

for i=1:N
% E contains errors per iteration
%E = zeros(

B = DeltaRule(X,Y,LearningRate,MinimumWeightChange,i);

%Y2 = B(1).*X(:,1).^B(1)+B(2).*X(:,2).^B(2) > 0;

%D = Y == Y2;
%end

% h =  W_0 + W_1 CrossProduct X1 + W_2 CrossProduct X2

h = B(1)+B(2).*X(:,1)+B(3).*X(:,2);

actualY = h > 0;

E(i) = sum(0.5.*(actualY - Y).^2);
end
% g(h) = actual value
plot(1:N,E,'-*c')
%xlabel('Iteration');
%ylabel('Error');