clf

plot(linspace(min(X(:,1)),max(X(:,1)),100),zeros(100,1),'-');
hold on

xlabel('x');
ylabel('y');

DS100 = X100(:,1)+2.*X100(:,2)-2;
DS50 = X50(:,1)+2.*X50(:,2)-2;
DS10 = X10(:,1)+2.*X10(:,2)-2;
DS5 = X5(:,1)+2.*X5(:,2)-2;



DSTrue5 = [];
DSFalse5= [];

X15 = [];
X25 = [];

for i = 1: 1000
    if h5(i) > 0
        DSTrue5 = [DSTrue5 h5(i)];
        X15 = [X15 X5(i,1)];
    else
        DSFalse5 = [DSFalse5 h5(i)];
        X25 = [X25 X5(i,1)];
    end
end


plot(X15,DSTrue5,'*r');
plot(X25,DSFalse5,'*g');