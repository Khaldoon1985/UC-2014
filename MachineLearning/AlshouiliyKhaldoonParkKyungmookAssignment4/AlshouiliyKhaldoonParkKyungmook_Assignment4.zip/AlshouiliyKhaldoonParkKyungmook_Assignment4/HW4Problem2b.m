%Machine Learning Assignment 4

% B = DeltaRuleBatchTrain(X,Y,LearningRate,MinimumWeightChange,MaximumPasses,B0)
%
% B                    = Discovered coefficients
%
% X                    = Predictors (exemplars in rows, variables in columns)
% Y                    = Target variable (0/1 values)
% LearningRate         = Learning rate                             (try 0.05)
% MinimumWeightChange  = Minimum change in weight norm to continue (try 0.01)
% MaximumPasses        = Maximum number of training passes         (try 50)
% B0                   = Initial guess for coefficients (optional, NaN for none)

% % Generate some random data
% X = randn(2500,4);
% Y = double( (X(:,1) < 0.1) & (X(:,2) > 0.2) );
%
% % Train single neuron model using delta rule
% B = DeltaRule(X,Y,0.05,0.01,50);
%
% % Recall using discovered model
% Z = Logistic(B(1) + X * B(2:end));
%
% % Measure resubstitution accuracy
% mean(Y == (Z > 0.5))

% Generate random pairs (x1, x2)
% g = x1 + 2*x2 - 2
% if x1 + 2*x2 - 2 > 0, assign results to positive class, i.e. 1
% if x1 + 2*x2 - 2 < 0 or x1 + 2*x2 - 2 = 0,
% assign results to negative class, i.e. 2
n = 1000;
N = 100;

LearningRate = 0.05;
MinimumWeightChange = 0.01;
MaximumPasses = N;
% Initial Guess
% B0

X = randn(n,2);
Y = double( X(:,1) + 2.*X(:,2) - 2 > 0 );
E = [];
eta = 0.5;
d = 0.9;
D = 1.02;
t = 1;

B = DeltaRule(X,Y,LearningRate,MinimumWeightChange,1);
h = B(1)+B(2).*X(:,1)+B(3).*X(:,2);
actualY = h > 0;
Einit = sum(0.5.*(actualY - Y).^2);
E = [E Einit];
i = 2;
while ( i < N + 1)
    B = DeltaRule(X,Y,LearningRate,MinimumWeightChange,i);
    h = B(1)+B(2).*X(:,1)+B(3).*X(:,2);
    actualY = h > 0;
    Ecurrent = sum(0.5.*(actualY - Y).^2);

if abs(Ecurrent - Einit) < t
    LearningRate = LearningRate*d;
    i = i - 1;
    if ( i == 1 ) 
        i = 2;
    end
else
    LearningRate = LearningRate * D;
    E = [E Ecurrent];
    Einit = Ecurrent;
    i = i + 1;
end
end